import pygame
import random
from object import Road, Player, Nitro, Bush, Button, \
					Obstacle, Coins, Fuel

pygame.init()
SCREEN = WIDTH, HEIGHT = 288, 512

info = pygame.display.Info()
width = info.current_w
height = info.current_h

if width >= height:
	win = pygame.display.set_mode(SCREEN, pygame.NOFRAME)
else:
	win = pygame.display.set_mode(SCREEN, pygame.NOFRAME | pygame.SCALED | pygame.FULLSCREEN)

clock = pygame.time.Clock()
FPS = 30

lane_pos = [60, 95, 142, 190]

WHITE = (255, 255, 255)
BLUE = (30, 144,255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLACK = (0, 0, 20)



font = pygame.font.SysFont('cursive', 32)
select_car = font.render('Select Car', True, GREEN)


bg = pygame.image.load('dodatki/background.png')

start_img = pygame.image.load('dodatki/home.png')
play_img = pygame.image.load('dodatki/buttons/play.png')
end_game_img = pygame.image.load('dodatki/end.jpg')
end_game_img = pygame.transform.scale(end_game_img, (WIDTH, HEIGHT))
game_over_img = pygame.image.load('dodatki/game_over.png')
game_over_img = pygame.transform.scale(game_over_img, (220, 220))
coin_img = pygame.image.load('dodatki/coin/1.png')
car_dodge_img = pygame.image.load('dodatki/car_dodge.png')

l_arrow = pygame.image.load('dodatki/buttons/arrow.png')
r_arrow = pygame.transform.flip(l_arrow, True, False)

start_btn_img = pygame.image.load('dodatki/buttons/home.png')
reset_img = pygame.image.load('dodatki/buttons/reset.png')


cars = []
type_car = 0
for i in range(1, 9):
	img = pygame.image.load(f'dodatki/cars/{i}.png')
	img = pygame.transform.scale(img, (59, 101))
	cars.append(img)

nitro_frames = []
nitro_counter = 0
for i in range(6):
	img = pygame.image.load(f'dodatki/nitro/{i}.gif')
	img = pygame.transform.flip(img, False, True)
	img = pygame.transform.scale(img, (18, 36))
	nitro_frames.append(img)

def center(image):
	return (WIDTH // 2) - image.get_width() // 2

play_btn = Button(play_img, (100, 34), center(play_img)-20, HEIGHT-80)
la_btn = Button(l_arrow, (32, 42), 40, 180)
ra_btn = Button(r_arrow, (32, 42), WIDTH-60, 180)

start_btn = Button(start_btn_img, (24, 24), WIDTH // 4 - 18, HEIGHT - 80)
reset_btn = Button(reset_img, (36,36), WIDTH // 2  - 18, HEIGHT - 86)

road = Road()
nitro = Nitro(WIDTH-80, HEIGHT-80)
p = Player(100, HEIGHT-120, type_car)

bush_group = pygame.sprite.Group()
coin_group = pygame.sprite.Group()
fuel_group = pygame.sprite.Group()
obstacle_group = pygame.sprite.Group()


start_page = True
car_page = False
game_page = False
end_page = False

move_left = False
move_right = False
nitro_on = False


counter = 0
counter_inc = 1
speed = 3
dodged = 0
coins = 0
start_fuel = 100

endx, enddx = 0, 0.5
gameovery = -50

running = True
while running:
	win.fill(BLACK)
	
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			running = False

		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_ESCAPE or event.key == pygame.K_q:
				running = False

			if event.key == pygame.K_LEFT:
				move_left = True

			if event.key == pygame.K_RIGHT:
				move_right = True

			if event.key == pygame.K_n or event.key == pygame.K_SPACE:
				nitro_on = True

		if event.type == pygame.KEYUP:
			if event.key == pygame.K_LEFT:
				move_left = False

			if event.key == pygame.K_RIGHT:
				move_right = False

			if event.key == pygame.K_n and event.key == pygame.K_SPACE:
				nitro_on = False
				speed = 3
				counter_inc = 1

		if event.type == pygame.MOUSEBUTTONDOWN:
			x, y = event.pos

			if nitro.rect.collidepoint((x, y)):
				nitro_on = True
			else:
				if x <= WIDTH // 2:
					move_left = True
				else:
					move_right = True

		if event.type == pygame.MOUSEBUTTONUP:
			move_left = False
			move_right = False
			nitro_on = False
			speed = 3
			counter_inc = 1

	if start_page:
		win.blit(start_img, (0,0))
		counter += 1
		if counter % 60 == 0:
			start_page = False
			car_page = True

	if car_page:
		win.blit(select_car, (center(select_car), 80))

		win.blit(cars[type_car], (WIDTH//2-30, 150))
		if la_btn.draw(win):
			type_car -= 1
			
			if type_car < 0:
				type_car = len(cars) - 1

		if ra_btn.draw(win):
			type_car += 1
			
			if type_car >= len(cars):
				type_car = 0

		if play_btn.draw(win):
			car_page = False
			game_page = True

		

			p = Player(100, HEIGHT-120, type_car)
			counter = 0

	if end_page:
		win.blit(end_game_img, (endx, 0))
		endx += enddx
		if endx >= 10 or endx<=-10:
			enddx *= -1

		win.blit(game_over_img, (center(game_over_img), gameovery))
		if gameovery < 16:
			gameovery += 1

		get_coin_img = font.render(f'{coins}', True, WHITE)
		num_car_dodge_img = font.render(f'{dodged}', True, WHITE)
		distance_img = font.render(f'Distance : {counter/1000:.2f} km', True, GREEN)

		win.blit(coin_img, (80, 240))
		win.blit(car_dodge_img, (50, 280))
		win.blit(get_coin_img, (180, 250))
		win.blit(num_car_dodge_img, (180, 300))
		win.blit(distance_img, (center(distance_img), (350)))

		if start_btn.draw(win):
			end_page = False
			start_page = True

			coins = 0
			dodged = 0
			counter = 0
			nitro.gas = 0
			start_fuel = 100

			endx, enddx = 0, 0.5
			gameovery = -50

		if reset_btn.draw(win):
			end_page = False
			game_page = True

			coins = 0
			dodged = 0
			counter = 0
			nitro.gas = 0
			start_fuel = 100

			endx, enddx = 0, 0.5
			gameovery = -50

		

	if game_page:
		win.blit(bg, (0,0))
		road.update(speed)
		road.draw(win)

		counter += counter_inc
		if counter % 60 == 0:
			bush = Bush(random.choice([0, WIDTH-30]), -20)
			bush_group.add(bush)

		if counter % 270 == 0:
			type = random.choices([1, 2], weights=[6, 4], k=1)[0]
			x = random.choice(lane_pos)+10
			if type == 1:
				count = random.randint(1, 3)
				for i in range(count):
					coin = Coins(x,-100 - (25 * i))
					coin_group.add(coin)
			elif type == 2:
				fuel = Fuel(x, -100)
				fuel_group.add(fuel)
		elif counter % 90 == 0:
			obs = random.choices([1, 2, 3], weights=[6,2,2], k=1)[0]
			obstacle = Obstacle(obs)
			obstacle_group.add(obstacle)

		if nitro_on and nitro.gas > 0:
			x, y = p.rect.centerx - 8, p.rect.bottom - 10
			win.blit(nitro_frames[nitro_counter], (x, y))
			nitro_counter = (nitro_counter + 1) % len(nitro_frames)

			speed = 10
			if counter_inc == 1:
				counter = 0
				counter_inc = 5

		if nitro.gas <= 0:
			speed = 3
			counter_inc = 1

		nitro.update(nitro_on)
		nitro.draw(win)
		obstacle_group.update(speed)
		obstacle_group.draw(win)
		bush_group.update(speed)
		bush_group.draw(win)
		coin_group.update(speed)
		coin_group.draw(win)
		fuel_group.update(speed)
		fuel_group.draw(win)

		p.update(move_left, move_right)
		p.draw(win)

		if start_fuel > 0:
			pygame.draw.rect(win, GREEN, (20, 20, start_fuel, 15), border_radius=5)
		pygame.draw.rect(win, WHITE, (20, 20, 100, 15), 2, border_radius=5)
		start_fuel -= 0.05

		if start_fuel <= 0:
			game_page = False
			end_page = True

		# kolizja i usuwanie
		for obstacle in obstacle_group:
			if obstacle.rect.y >= HEIGHT:
				if obstacle.type == 1:
					dodged += 1
				obstacle.kill() 

			if pygame.sprite.collide_mask(p, obstacle):
				pygame.draw.rect(win, RED, p.rect, 1)
				speed = 0

				game_page = False
				end_page = True

				bush_group.empty()
				coin_group.empty()
				fuel_group.empty()
				obstacle_group.empty()

		if pygame.sprite.spritecollide(p, coin_group, True):
			coins += 1
		

		if pygame.sprite.spritecollide(p, fuel_group, True):
			start_fuel += 25
		
			if start_fuel >= 100:
				start_fuel = 100

	pygame.draw.rect(win, BLUE, (0, 0, WIDTH, HEIGHT), 3)
	clock.tick(FPS)
	pygame.display.update()

pygame.quit()