
function Step() {
    return <div>Step</div>
}

export default Step;