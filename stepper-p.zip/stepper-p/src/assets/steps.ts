const steps = [
    {
        id: 0,
        name: "Register a account",
        content: "<h1>Register form</h1>"
    },
    {
        id: 1,
        name: "Choose a plan",
        content: "<h1>Plans are: Basic, Pro, Enterprise</h1>"
    },
    {
        id: 2,
        name: "Create outstanding things!",
        content: "<h1>Good luck and have fun!</h1>"
    },


]

export default steps;