export default class Player{
    constructor(camera){
        this.camera = camera
    }
}