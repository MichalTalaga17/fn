# Notatnik na Pythona

Jak ktoś chce, to niech pobierze

# TODO

- Ctrl+S save
- Open file for editing in window

